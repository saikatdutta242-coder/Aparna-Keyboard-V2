package com.aparna.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView

class AparnaIMEService : InputMethodService() {
    override fun onCreateInputView(): View {
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(object {
            @JavascriptInterface
            fun commitText(text: String) {
                currentInputConnection?.commitText(text, 1)
            }
            @JavascriptInterface
            fun deleteSurroundingText() {
                currentInputConnection?.deleteSurroundingText(1, 0)
            }
        }, "AndroidIME")
        webView.loadUrl("file:///android_asset/Aparna_Android_Keyboard.html")
        return webView
    }
}
